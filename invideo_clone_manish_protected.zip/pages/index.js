// pages/index.js
import React, { useState, useEffect } from "react";
import { createFFmpeg, fetchFile } from "@ffmpeg/ffmpeg";

const ffmpeg = createFFmpeg({ log: true });
const PASSWORD = "manish(362154)";

export default function Home() {
  const [authenticated, setAuthenticated] = useState(false);
  const [inputPassword, setInputPassword] = useState("");

  if (!authenticated) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", justifyContent: "center", alignItems: "center", background: "#f3f4f6" }}>
        <div style={{ background: "white", padding: "2rem", borderRadius: "1rem", boxShadow: "0 0 20px rgba(0,0,0,0.1)" }}>
          <h2 style={{ fontSize: "1.5rem", marginBottom: "1rem" }}>🔐 Enter Password to Access</h2>
          <input
            type="password"
            placeholder="Enter password..."
            value={inputPassword}
            onChange={(e) => setInputPassword(e.target.value)}
            style={{ padding: "0.5rem", borderRadius: "0.5rem", border: "1px solid #ccc", width: "100%" }}
          />
          <button
            onClick={() => {
              if (inputPassword === PASSWORD) setAuthenticated(true);
              else alert("❌ Wrong password!");
            }}
            style={{ marginTop: "1rem", background: "#4f46e5", color: "white", padding: "0.5rem 1rem", border: "none", borderRadius: "0.5rem", cursor: "pointer" }}
          >
            Unlock
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ textAlign: "center", padding: "2rem" }}>
      <h1>🔓 Welcome, Manish!</h1>
      <p>Your AI Video Creator is now unlocked. You can now paste the full original code here below this return.</p>
      {/* 🔽 Place full video creator code here */}
    </div>
  );
}
